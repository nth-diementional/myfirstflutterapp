import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key); // Corrected the constructor syntax

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        backgroundColor: Colors.black,
        leading: Image.asset(
          'assets/wine.png',
          width: 24.0,
        ),
        titleSpacing: 0.5,
        title: Text(
          'Wine Collection',
          style: TextStyle(
            fontSize: 24,
            fontFamily: 'Italiana',
            color: Colors.white,
          ),
        ),
      ),
      body: WineItem(
        data: wineDataList[0],
        isLiked: false, // Corrected the property name to 'isLiked'
        onLikePressed: () {}, // You need to provide the onPressed callback
      ),
    );
  }
}

