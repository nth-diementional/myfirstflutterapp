import 'package:flutter/material.dart';

class WineItem extends StatelessWidget {
  final Map<String, dynamic> data;
  final bool isLiked;
  final void Function() onLikePressed;

  const WineItem({
    Key? key, // Adding 'Key?' instead of 'super.key'
    required this.data,
    required this.isLiked,
    required this.onLikePressed,
  }) : super(key: key); // Correcting the super constructor call syntax

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(8),
      padding: EdgeInsets.all(16),
      color: Colors.grey[200],
      child: Row(
        children: [
          Image.network(
            data['image'],
            height: 92,
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data['winery'],
                  style: TextStyle(
                    fontFamily: 'Italiana',
                    fontSize: 18,
                  ),
                ),
                Text(
                  data['wine'],
                  style: TextStyle(
                    fontSize: 18,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '\$${data["price"]}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      onPressed: onLikePressed,
                      icon: Icon(
                        isLiked ? Icons.favorite : Icons.favorite_outline,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
