import 'package:flutter/material.dart';
import 'package:flutter_app/pages/home.dart';

void main() {
  runApp(const WineCollectionApp());
}

class WineCollectionApp extends StatelessWidget {
  const WineCollectionApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wine Collection',
      theme: ThemeData(
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.black87),
        useMaterial3: true,
      ),
      home: Home(),
      // Home page of the app
      // home: Home(),
    );
  }
}
